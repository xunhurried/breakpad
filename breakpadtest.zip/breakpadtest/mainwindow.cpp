#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "client/mac/handler/exception_handler.h"
#include<iostream>
#ifdef _WINDOWS
bool minidumpCB(const wchar_t *dump_path, const wchar_t *id, void *context, EXCEPTION_POINTERS *exinfo, MDRawAssertionInfo *assertion, bool succeeded) {
#else
bool minidumpCB(const char* dump_path, const char* id, void* context, bool succeeded) {
#endif
    if (succeeded) {
        std::cout << "Mini Dump file: " << id << ".dump Path: " << dump_path << std::endl;
    }
    return succeeded;
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    google_breakpad::ExceptionHandler eh("/tmp",  // minidump文件写入到的目录
         NULL,
         minidumpCB,
         NULL,
         true,
         NULL);

    //volatile int* a = (int*)(NULL);
      // *a = 1;
}

MainWindow::~MainWindow()
{
    delete ui;
}

